﻿namespace DTR_actual
{
    partial class frmDTR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDTR));
            this.axMap1 = new AxMapWinGIS.AxMap();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPointShape = new System.Windows.Forms.TextBox();
            this.txtDtr = new System.Windows.Forms.TextBox();
            this.btnSelPoint = new System.Windows.Forms.Button();
            this.btnSelLine = new System.Windows.Forms.Button();
            this.btnProcess = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDtrPercentage = new System.Windows.Forms.Label();
            this.lblActualLength = new System.Windows.Forms.Label();
            this.lblDtrLength = new System.Windows.Forms.Label();
            this.lblProgress = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.axMap1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // axMap1
            // 
            this.axMap1.Enabled = true;
            this.axMap1.Location = new System.Drawing.Point(12, 138);
            this.axMap1.Name = "axMap1";
            this.axMap1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMap1.OcxState")));
            this.axMap1.Size = new System.Drawing.Size(690, 308);
            this.axMap1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select Drive Point Shape File";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select DTR Shape File";
            // 
            // txtPointShape
            // 
            this.txtPointShape.Location = new System.Drawing.Point(205, 44);
            this.txtPointShape.Name = "txtPointShape";
            this.txtPointShape.Size = new System.Drawing.Size(193, 20);
            this.txtPointShape.TabIndex = 3;
            // 
            // txtDtr
            // 
            this.txtDtr.Location = new System.Drawing.Point(205, 71);
            this.txtDtr.Name = "txtDtr";
            this.txtDtr.Size = new System.Drawing.Size(193, 20);
            this.txtDtr.TabIndex = 4;
            // 
            // btnSelPoint
            // 
            this.btnSelPoint.Location = new System.Drawing.Point(404, 42);
            this.btnSelPoint.Name = "btnSelPoint";
            this.btnSelPoint.Size = new System.Drawing.Size(34, 23);
            this.btnSelPoint.TabIndex = 5;
            this.btnSelPoint.Text = "---";
            this.btnSelPoint.UseVisualStyleBackColor = true;
            this.btnSelPoint.Click += new System.EventHandler(this.btnSelPoint_Click);
            // 
            // btnSelLine
            // 
            this.btnSelLine.Location = new System.Drawing.Point(404, 71);
            this.btnSelLine.Name = "btnSelLine";
            this.btnSelLine.Size = new System.Drawing.Size(34, 23);
            this.btnSelLine.TabIndex = 6;
            this.btnSelLine.Text = "---";
            this.btnSelLine.UseVisualStyleBackColor = true;
            this.btnSelLine.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(205, 97);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(72, 23);
            this.btnProcess.TabIndex = 7;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(157, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 18);
            this.label3.TabIndex = 8;
            this.label3.Text = "DTR Vs Actual drive";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblDtrPercentage);
            this.groupBox1.Controls.Add(this.lblActualLength);
            this.groupBox1.Controls.Add(this.lblDtrLength);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(444, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(257, 116);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Results";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "DTR Length :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Actual Length :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "DTR Cover(%) :";
            // 
            // lblDtrPercentage
            // 
            this.lblDtrPercentage.AutoSize = true;
            this.lblDtrPercentage.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDtrPercentage.Location = new System.Drawing.Point(121, 76);
            this.lblDtrPercentage.Name = "lblDtrPercentage";
            this.lblDtrPercentage.Size = new System.Drawing.Size(34, 13);
            this.lblDtrPercentage.TabIndex = 5;
            this.lblDtrPercentage.Text = "###";
            // 
            // lblActualLength
            // 
            this.lblActualLength.AutoSize = true;
            this.lblActualLength.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActualLength.Location = new System.Drawing.Point(121, 51);
            this.lblActualLength.Name = "lblActualLength";
            this.lblActualLength.Size = new System.Drawing.Size(34, 13);
            this.lblActualLength.TabIndex = 4;
            this.lblActualLength.Text = "###";
            // 
            // lblDtrLength
            // 
            this.lblDtrLength.AutoSize = true;
            this.lblDtrLength.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDtrLength.Location = new System.Drawing.Point(121, 26);
            this.lblDtrLength.Name = "lblDtrLength";
            this.lblDtrLength.Size = new System.Drawing.Size(34, 13);
            this.lblDtrLength.TabIndex = 3;
            this.lblDtrLength.Text = "###";
            // 
            // lblProgress
            // 
            this.lblProgress.AutoSize = true;
            this.lblProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgress.Location = new System.Drawing.Point(13, 109);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new System.Drawing.Size(21, 13);
            this.lblProgress.TabIndex = 10;
            this.lblProgress.Text = "##";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(13, 126);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(688, 10);
            this.progressBar1.TabIndex = 11;
            // 
            // frmDTR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(710, 453);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.btnSelLine);
            this.Controls.Add(this.btnSelPoint);
            this.Controls.Add(this.txtDtr);
            this.Controls.Add(this.txtPointShape);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.axMap1);
            this.MaximizeBox = false;
            this.Name = "frmDTR";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DTR Vs Actual";
            this.Load += new System.EventHandler(this.frmDTR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axMap1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxMapWinGIS.AxMap axMap1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPointShape;
        private System.Windows.Forms.TextBox txtDtr;
        private System.Windows.Forms.Button btnSelPoint;
        private System.Windows.Forms.Button btnSelLine;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblDtrPercentage;
        private System.Windows.Forms.Label lblActualLength;
        private System.Windows.Forms.Label lblDtrLength;
        private System.Windows.Forms.Label lblProgress;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}

