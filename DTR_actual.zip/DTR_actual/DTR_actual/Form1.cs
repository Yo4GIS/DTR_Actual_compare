﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MapWinGIS;

namespace DTR_actual
{
    public partial class frmDTR : Form
    {
        string pntFilePath = string.Empty;
        string lineFilePath = string.Empty;

        public frmDTR()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Shape Files|*.shp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtDtr.Text = ofd.FileName;
                lineFilePath = txtDtr.Text;
            }
        }

        private void frmDTR_Load(object sender, EventArgs e)
        {
            axMap1.Projection = tkMapProjection.PROJECTION_WGS84;
            axMap1.Tiles.Provider = tkTileProvider.OpenStreetMap;
            axMap1.Tiles.ProviderId = (int)tkTileProvider.OpenStreetMap;
            axMap1.KnownExtents = tkKnownExtents.keIndia;

            DateTime d1 = new DateTime(2024, 01, 10, 15, 20, 40);
            DateTime d2 = DateTime.Now;
            int cmp = DateTime.Compare(d2, d1);
            if (cmp >= 1)
            {
                MessageBox.Show("Sorry Trial Period over!! Please contact to Administrator", "License Trial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            try
            {
                progressBar1.Minimum = 0;
                progressBar1.Maximum = 10;
                Shapefile sfPoint = new Shapefile();
                bool chkPoint = sfPoint.Open(pntFilePath, null);

                Shapefile sfLine = new Shapefile();
                bool chkLine = sfLine.Open(lineFilePath, null);

                Shapefile sfLineNew = new Shapefile();
                sfLineNew.CreateNewWithShapeID("", ShpfileType.SHP_POLYLINE);
                GeoProjection gp = new GeoProjection();
                gp.ImportFromEPSG(4326);

                sfLineNew.GeoProjection = gp;

                MapWinGIS.Shape shp = new Shape();
                shp.Create(ShpfileType.SHP_POLYLINE);

                lblProgress.Text = "Reading Drive Data";
                progressBar1.Value = 2;
                Application.DoEvents();

                for (int i = 0; i < sfPoint.NumShapes; i++)
                {
                    Shape shpPnt = sfPoint.Shape[i];
                    //IPoint pnt = shpPnt as IPoint;                
                    int shpIndex = shp.AddPoint(shpPnt.Center.x, shpPnt.Center.y);

                }


                progressBar1.Value = 5;
                Application.DoEvents();


                int a = sfLineNew.EditAddShape(shp);

                //sfLineNew.SaveAs(@"E:\Linkquest\0412\Data\out1\a1.shp");
                MapWinGIS.GeoProjection gp1 = new MapWinGIS.GeoProjection();
                gp1.ImportFromEPSG(4326);

                MapWinGIS.GeoProjection gpWGS = new MapWinGIS.GeoProjection();
                gpWGS.ImportFromEPSG(4326);

                MapWinGIS.GeoProjection gpMarcator = new MapWinGIS.GeoProjection();
                gpMarcator.ImportFromEPSG(3857);

                int repc = 0;
                //sfLineNew.Reproject(gpMarcator, ref repc);


                Utils u = new Utils();
                Shapefile sfProject = u.ReprojectShapefile(sfLineNew, gpWGS, gpMarcator);
                sfLineNew.Close();

                //MapWinGIS.Shape shp11 = new Shape();
                //shp11.Create(ShpfileType.SHP_POLYLINE);

                lblProgress.Text = "Reading DTR Data";
                Application.DoEvents();

                Shapefile sfLineProjected = new Shapefile();
                sfLineProjected.CreateNewWithShapeID("", ShpfileType.SHP_POLYLINE);
                sfLineProjected.GeoProjection = gpMarcator;

                //sfLineProjected.Close();

                //for (int i=0;i<=sfProject.NumShapes;i++)
                //{
                double lenActual = 0;

                lblProgress.Text = "Reading Points Data";
                Application.DoEvents();


                Shape s1 = sfProject.Shape[0];
                for (int j = 0; j < s1.numPoints; j++)
                {
                    if (j == 0)
                        continue;

                    Shape shp11 = new Shape();
                    shp11.Create(ShpfileType.SHP_POLYLINE);

                    shp11.AddPoint(s1.Point[j].x, s1.Point[j].y);
                    shp11.AddPoint(s1.Point[j - 1].x, s1.Point[j - 1].y);
                    double len = shp11.Length;
                    if (len < 10)
                    {
                        lenActual = lenActual + len;
                        int a11 = sfLineProjected.EditAddShape(shp11);
                    }

                }

                lblProgress.Text = "Calculating distance";
                Application.DoEvents();


                progressBar1.Value = 7;
                Application.DoEvents();


                sfProject.Close();
                //sfLineProjected.SaveAs(@"D:\Personal\Linkquest\Applications\Data\apro.shp");
                //sfLineProjected.Close();

                lblProgress.Text = "Project Data";
                Application.DoEvents();

                Shapefile sfProjectDtr = u.ReprojectShapefile(sfLine, gpWGS, gpMarcator);

                double dtrLength = 0;

                for (int i = 0; i < sfProjectDtr.NumShapes; i++)
                {
                    dtrLength = dtrLength + sfProjectDtr.Shape[i].Length;
                }
                lblDtrLength.Text = Convert.ToString(Math.Round(dtrLength / 1000, 2)) + " Km";
                Application.DoEvents();
                sfProjectDtr.GeoProjection = gpMarcator;
                sfProjectDtr.Save();
                //bool a1 = sfProjectDtr.SaveAs(@"D:\Personal\Linkquest\Applications\Data\prodtr.shp");


                Shapefile ss = new Shapefile();
                //a1= ss.Open(@"D:\Personal\Linkquest\Applications\Data\apro.shp");

                Shapefile sfBufferSurvey = sfLineProjected.BufferByDistance(10, 25, false, false);
                sfBufferSurvey.GeoProjection = gpMarcator;
                sfBufferSurvey.Save();
                Shapefile f1 = sfProjectDtr.Clip(false, sfBufferSurvey, false);
                f1.GeoProjection = gpMarcator;
                f1.Save();


                double dtrLength1 = 0;

                for (int i = 0; i < f1.NumShapes; i++)
                {
                    dtrLength1 = dtrLength1 + f1.Shape[i].Length;
                }

                lblDtrPercentage.Text = Convert.ToString(Math.Round((dtrLength1 / dtrLength) * 100, 2));
                Application.DoEvents();

                lblActualLength.Text = Convert.ToString(Math.Round(lenActual / 1000)) + " Km";
                Application.DoEvents();


                //f1.SaveAs(@"D:\Personal\Linkquest\Applications\Data\cliped.shp");
                //f1.Close();


                //sfBufferSurvey.SaveAs(@"D:\Personal\Linkquest\Applications\Data\aproBuff.shp");
                sfBufferSurvey.Close();
                //}




                axMap1.AddLayerFromFilename(pntFilePath, tkFileOpenStrategy.fosAutoDetect, true);
                axMap1.AddLayerFromFilename(lineFilePath, tkFileOpenStrategy.fosAutoDetect, true);
                //axMap1.AddLayerFromFilename(@"D:\Personal\Linkquest\Applications\Data\a.shp", tkFileOpenStrategy.fosAutoDetect, true);
                axMap1.ZoomToMaxExtents();

                lblProgress.Text = "Completed";
                Application.DoEvents();

                progressBar1.Value = 10;
                Application.DoEvents();
                MessageBox.Show("Process xecuted successfully");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnSelPoint_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Shape Files|*.shp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtPointShape.Text = ofd.FileName;
                pntFilePath = txtPointShape.Text;
            }
        }
    }
}
