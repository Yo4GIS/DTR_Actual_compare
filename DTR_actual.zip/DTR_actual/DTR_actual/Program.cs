﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MapWinGIS;
using System.IO;

namespace DTR_actual
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length == 2)
            {
                DateTime d1 = new DateTime(2024, 01,10 , 15, 20, 40);
                DateTime d2 = DateTime.Now;
                int cmp = DateTime.Compare(d2, d1);
                if (cmp >= 1)
                {
                    Console.WriteLine("Sorry Trial Period over!! Please contact to Administrator", "License Trial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                getResult(args);
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmDTR());
            }
        }

        public static void getResult(string[] args)
        {
            try
            {
                string pntFilePath = args[0];
                string lineFilePath = args[1];
                Shapefile sfPoint = new Shapefile();
                bool chkPoint = sfPoint.Open(pntFilePath, null);

                Shapefile sfLine = new Shapefile();
                bool chkLine = sfLine.Open(lineFilePath, null);

                Shapefile sfLineNew = new Shapefile();
                sfLineNew.CreateNewWithShapeID("", ShpfileType.SHP_POLYLINE);
                GeoProjection gp = new GeoProjection();
                gp.ImportFromEPSG(4326);

                sfLineNew.GeoProjection = gp;

                MapWinGIS.Shape shp = new Shape();
                shp.Create(ShpfileType.SHP_POLYLINE);



                for (int i = 0; i < sfPoint.NumShapes; i++)
                {
                    Shape shpPnt = sfPoint.Shape[i];
                    //IPoint pnt = shpPnt as IPoint;                
                    int shpIndex = shp.AddPoint(shpPnt.Center.x, shpPnt.Center.y);

                }

                int a = sfLineNew.EditAddShape(shp);

                //sfLineNew.SaveAs(@"D:\Personal\Linkquest\Applications\Data\a1.shp");
                MapWinGIS.GeoProjection gp1 = new MapWinGIS.GeoProjection();
                gp1.ImportFromEPSG(4326);

                MapWinGIS.GeoProjection gpWGS = new MapWinGIS.GeoProjection();
                gpWGS.ImportFromEPSG(4326);

                MapWinGIS.GeoProjection gpMarcator = new MapWinGIS.GeoProjection();
                gpMarcator.ImportFromEPSG(3857);

                int repc = 0;
                //sfLineNew.Reproject(gpMarcator, ref repc);


                Utils u = new Utils();
                Shapefile sfProject = u.ReprojectShapefile(sfLineNew, gpWGS, gpMarcator);
                sfLineNew.Close();

                //MapWinGIS.Shape shp11 = new Shape();
                //shp11.Create(ShpfileType.SHP_POLYLINE);


                Shapefile sfLineProjected = new Shapefile();
                sfLineProjected.CreateNewWithShapeID("", ShpfileType.SHP_POLYLINE);
                sfLineProjected.GeoProjection = gpMarcator;

                //sfLineProjected.Close();

                //for (int i=0;i<=sfProject.NumShapes;i++)
                //{
                double lenActual = 0;



                Shape s1 = sfProject.Shape[0];
                for (int j = 0; j < s1.numPoints; j++)
                {
                    if (j == 0)
                        continue;

                    Shape shp11 = new Shape();
                    shp11.Create(ShpfileType.SHP_POLYLINE);

                    shp11.AddPoint(s1.Point[j].x, s1.Point[j].y);
                    shp11.AddPoint(s1.Point[j - 1].x, s1.Point[j - 1].y);
                    double len = shp11.Length;
                    if (len < 10)
                    {
                        lenActual = lenActual + len;
                        int a11 = sfLineProjected.EditAddShape(shp11);
                    }

                }




                sfProject.Close();
                //sfLineProjected.SaveAs(@"D:\Personal\Linkquest\Applications\Data\apro.shp");
                //sfLineProjected.Close();



                Shapefile sfProjectDtr = u.ReprojectShapefile(sfLine, gpWGS, gpMarcator);

                double dtrLength = 0;

                for (int i = 0; i < sfProjectDtr.NumShapes; i++)
                {
                    dtrLength = dtrLength + sfProjectDtr.Shape[i].Length;
                }

                sfProjectDtr.GeoProjection = gpMarcator;
                sfProjectDtr.Save();
                //bool a1 = sfProjectDtr.SaveAs(@"D:\Personal\Linkquest\Applications\Data\prodtr.shp");


                Shapefile ss = new Shapefile();
                //a1= ss.Open(@"D:\Personal\Linkquest\Applications\Data\apro.shp");

                Shapefile sfBufferSurvey = sfLineProjected.BufferByDistance(10, 25, false, false);
                sfBufferSurvey.GeoProjection = gpMarcator;
                sfBufferSurvey.Save();
                Shapefile f1 = sfProjectDtr.Clip(false, sfBufferSurvey, false);
                f1.GeoProjection = gpMarcator;
                f1.Save();


                double dtrLength1 = 0;

                for (int i = 0; i < f1.NumShapes; i++)
                {
                    dtrLength1 = dtrLength1 + f1.Shape[i].Length;
                }


                sfBufferSurvey.Close();
                //}

                var path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string fileName = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                StreamWriter sw = new StreamWriter(path + "\\" + fileName + ".txt");
                sw.WriteLine("DTR Length:" + Convert.ToString(Math.Round(dtrLength / 1000, 2)) + " Km");
                sw.WriteLine("Actual Length:" + Convert.ToString(Math.Round(lenActual / 1000)) + " Km");
                sw.WriteLine("DTR Percenrage Cover:" + Convert.ToString(Math.Round((dtrLength1 / dtrLength) * 100, 2)));
                sw.Close();
                Console.Write("Completed");
            }
            catch(Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

    }
}
